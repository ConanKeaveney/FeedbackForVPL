#! /bin/bash

cat > vpl_execution <<EEOOFF
#! /bin/bash
 
prog1=main


g++ \${prog1}.cpp  &> grepLines.out


if ((\$? > 0)); then
     echo "Error compiling your program"
     cat grepLines.out
     exit
fi
./a.out


EEOOFF

chmod +x vpl_execution

