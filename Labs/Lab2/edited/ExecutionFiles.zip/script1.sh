#!/bin/bash
./a.out < data1.txt > output.out
./a.out < data2.txt > output.out
./a.out < data3.txt > output.out
./a.out < data4.txt > output.out
./a.out < data5.txt > output.out
./a.out < big.txt > output.out