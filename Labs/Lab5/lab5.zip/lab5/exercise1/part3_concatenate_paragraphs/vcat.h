#ifndef GUARD_VCAT_H
#define GUARD_VCAT_H
 
#include <string>
#include <vector>
 
std::vector<std::string> vcat(const std::vector<std::string>&, const std::vector<std::string>&);
 
#endif // GUARD_VCAT_H
