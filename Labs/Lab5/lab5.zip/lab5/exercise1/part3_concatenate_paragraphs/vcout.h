#ifndef GUARD_VCOUT_H
#define GUARD_VCOUT_H
 
#include <string>
#include <vector>
 
int vcout(const std::vector<std::string>&);
 
#endif // GUARD_VCOUT_H
