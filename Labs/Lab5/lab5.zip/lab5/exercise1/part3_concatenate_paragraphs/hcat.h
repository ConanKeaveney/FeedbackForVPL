#ifndef GUARD_HCAT_H
#define GUARD_HCAT_H
 
#include <string>
#include <vector>
 
std::vector<std::string> hcat(const std::vector<std::string>&, const std::vector<std::string>&);
 
#endif // GUARD_HCAT_H
