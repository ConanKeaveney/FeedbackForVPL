#ifndef GUARD_MEDIAN_H
#define GUARD_MEDIAN_H
 
// median.h - final version
#include <vector>
double median(std::vector<double>);
 
#endif // GUARD_MEDIAN_H
