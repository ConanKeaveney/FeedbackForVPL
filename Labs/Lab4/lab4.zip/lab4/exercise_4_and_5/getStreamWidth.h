#ifndef GUARD_GETSTREAMWIDTH_H
#define GUARD_GETSTREAMWIDTH_H
 
std::streamsize getStreamWidth(int number);
 
#endif // GUARD_GETSTREAMWIDTH_H
