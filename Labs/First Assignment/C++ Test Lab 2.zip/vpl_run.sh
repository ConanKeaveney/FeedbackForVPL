#!/bin/bash
echo "#!/bin/bash" > vpl_execution
if [ -f ./vpl_evaluate.sh ] ; then
      echo "python2.7 evaluateProgram.py" >> vpl_execution
else
      echo "python2.7 runProgram.py" >> vpl_execution
fi
chmod +x vpl_execution
