# runProgram.py
# students, do not modify this file.  It will be used to test your program.

import sys

#--- run the program to test ---
import Lab_9_Additional

#--- display the contents of the sample.txt file which should 
#--- have been modified by the program under test.

print "\n---Output.txt---"
try:
    file = open( "Output.txt", "r" )
    print file.read(), 
    file.close()
except IOError as e:
    print "I/O error({0}): {1}".format(e.errno, e.strerror)
except:
    print "Unexpected error:", sys.exc_info()[0]
    raise
