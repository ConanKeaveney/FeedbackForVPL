   # code included in vpl_evaluate.sh.  All $-signs prefixed with back-slash.
   # $user contains output from student program
   # $expected contains expected output
   cat \$user | sort | xargs  > \${user}_sorted
   cat \$expected | sort | xargs > \${expected}_sorted
   diff -y -w -B --ignore-all-space \${user}_sorted \${expected}_sorted > diff.out

   if ((\$? > 0)); then
      echo "Comment :=>> Your output is incorrect."
      echo "Comment :=>> ---------------"
      echo "Comment :=>>- Your output:"
      echo "Comment :=>> ---------------"
      echo "<|--"
      cat \$user
      echo "--|>"
      echo ""
      echo "Comment :=>> ---------------"
      echo "Comment :=>>- Expected output "
      echo "Comment :=>> ---------------"
      echo "<|--"
      cat \$expected
      echo "--|>"
   else
      echo "Comment :=>> Correct output."
      noTestsPassed=\$((noTestsPassed+1))
   fi
