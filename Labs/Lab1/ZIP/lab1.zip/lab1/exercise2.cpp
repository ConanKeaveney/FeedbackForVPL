#include <iostream>
int main()
{
  std::cout << "This (\") is a quote, and this (\\) is a blackslash" << std::endl;
  return 0;
}
